package cert;

import java.util.ArrayList;
import java.util.List;

public class TestListSize {

    public static void main(String[] args) {
        
    	List l = new ArrayList();
        
        int size = l.size();
        
        System.out.println(size);

    }

}
