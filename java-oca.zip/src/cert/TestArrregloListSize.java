package cert;


public class TestArrregloListSize {

    public static void main(String[] args) {
        
        char[] c = new char[2];
        
        int length = c.length;
        
        System.out.println(length);

    }

}
