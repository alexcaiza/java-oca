package cert;

public class TestWhile1 {

    /**
     * @param args
     */
    public static void main(String[] args) {
        
    	//do {
    		int y=1;
    		System.out.println(y++ + "");
    	//} while (y<=10);
    		
    	//No compila porque y tiene que esta fuera del do {
        
    }

}
