package cert;

public class TestHerencia1 {
    public static void main(String[] args) {
    	
    }

}
