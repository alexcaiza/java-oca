package cert;

import java.util.Date;

public class TestArregloDeclarations {

    public static void main(String[] args) {
        
        Date[] dates[] = new Date[2][];
        
        //String beans[] = new beans[6];
        
        int [][] scores = new int[5][];
        
        Object[] dat0 = new Object[0];
        Object[][] dat1 = new Object[0][0];
        
        Object[][][] cubbies = new Object[3][0][5];
        
        //int [][] types = new int[];
        
        //int [][] types = new int[][];

    }

}
